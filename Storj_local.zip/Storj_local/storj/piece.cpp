//
// Created by ousing9 on 2022/3/9.
//

#include <utility>

#include "piece.h"

storj::piece::piece() = default;

