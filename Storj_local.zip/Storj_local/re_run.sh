cmake CMakeLists.txt
make
