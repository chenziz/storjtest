#!/bin/sh
autoreconf --force --install -I m4
