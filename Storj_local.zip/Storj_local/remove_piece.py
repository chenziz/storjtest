import sqlite3
import os

con = sqlite3.connect("storj.db")

cur = con.cursor()
num = 1
num2 = 50
while(num2>0):
       cur.execute('select storage_node_id from piece ORDER BY RANDOM() limit ?',(num,) )
       for x in cur:
              k = x[0]
       print(k)
       del_dir = "./storage_nodes/"+k
       print(del_dir)
       del_list = os.listdir(del_dir)
       print(del_list)
       for file in del_list:
              filePath = os.path.join(del_dir, file)
              # print(del_list)
              # print(os.path.join(del_dirs, file)
              os.remove(filePath)
       
       num2 -= 1
# print(cur.fetchall())

# select storage_node_id from piece 
# 选取一个storage node

# cur.execute("DELETE FROM test WHERE id=?", (1,))

# con.commit()

# cur.close()